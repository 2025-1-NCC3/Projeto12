package br.com.fecapccp.uberreport.services.usuario;

public interface DeletarUsuario {

    void deletarUsuario(int userId);
}
