package br.com.fecapccp.uberreport.services.usuario.response;

public class CodigoResponse {
    private String mensagem;

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}
