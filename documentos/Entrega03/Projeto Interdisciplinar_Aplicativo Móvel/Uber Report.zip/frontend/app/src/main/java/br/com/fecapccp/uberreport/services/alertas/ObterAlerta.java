package br.com.fecapccp.uberreport.services.alertas;

import br.com.fecapccp.uberreport.services.alertas.model.Alerta;

public interface ObterAlerta {
    Alerta obterAlerta();
}
