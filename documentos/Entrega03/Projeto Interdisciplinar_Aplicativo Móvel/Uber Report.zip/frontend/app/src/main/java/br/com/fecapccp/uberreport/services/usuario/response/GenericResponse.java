package br.com.fecapccp.uberreport.services.usuario.response;

public class GenericResponse {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}