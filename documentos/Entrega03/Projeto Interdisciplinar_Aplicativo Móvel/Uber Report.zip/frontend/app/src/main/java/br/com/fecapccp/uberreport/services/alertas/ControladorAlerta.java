package br.com.fecapccp.uberreport.services.alertas;

public interface ControladorAlerta {
    void controlarAlertas();
}
