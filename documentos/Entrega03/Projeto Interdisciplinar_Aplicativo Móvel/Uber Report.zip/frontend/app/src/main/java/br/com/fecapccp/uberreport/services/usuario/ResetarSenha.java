package br.com.fecapccp.uberreport.services.usuario;


import br.com.fecapccp.uberreport.services.usuario.request.LoginRequest;

public interface ResetarSenha {

    void resetarSenha(LoginRequest loginRequest);

}
