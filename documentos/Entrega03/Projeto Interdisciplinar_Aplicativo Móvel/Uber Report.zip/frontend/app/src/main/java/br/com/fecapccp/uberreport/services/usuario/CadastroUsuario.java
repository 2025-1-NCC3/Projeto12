package br.com.fecapccp.uberreport.services.usuario;

import br.com.fecapccp.uberreport.models.Usuario;

public interface CadastroUsuario {
    void cadastrarUsuario(Usuario usuario);
}
